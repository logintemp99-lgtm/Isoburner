package com.example.isoburner

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbDeviceConnection
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Minimal USB Mass Storage driver (Bulk-Only Transport + SCSI). Works without root. */
class UsbMassStorage(private val manager: UsbManager, private val device: UsbDevice) : Closeable {

    private var conn: UsbDeviceConnection? = null
    private var intf: UsbInterface? = null
    private lateinit var epIn: UsbEndpoint
    private lateinit var epOut: UsbEndpoint
    private var tag = 1

    var blockSize = 512
        private set
    var blockCount = 0L
        private set
    val sizeBytes: Long get() = blockCount * blockSize

    companion object {
        /** Mass storage class (8), SCSI subclass (6), Bulk-Only protocol (0x50). */
        fun findInterface(d: UsbDevice): UsbInterface? {
            for (i in 0 until d.interfaceCount) {
                val f = d.getInterface(i)
                if (f.interfaceClass == UsbConstants.USB_CLASS_MASS_STORAGE &&
                    f.interfaceSubclass == 6 && f.interfaceProtocol == 0x50
                ) return f
            }
            return null
        }
    }

    fun open() {
        val f = findInterface(device) ?: throw IOException("Not a USB mass-storage drive")
        var inEp: UsbEndpoint? = null
        var outEp: UsbEndpoint? = null
        for (n in 0 until f.endpointCount) {
            val e = f.getEndpoint(n)
            if (e.type != UsbConstants.USB_ENDPOINT_XFER_BULK) continue
            if (e.direction == UsbConstants.USB_DIR_IN) inEp = e else outEp = e
        }
        epIn = inEp ?: throw IOException("Bulk IN endpoint missing")
        epOut = outEp ?: throw IOException("Bulk OUT endpoint missing")

        val c = manager.openDevice(device) ?: throw IOException("Cannot open device")
        if (!c.claimInterface(f, true)) {
            c.close()
            throw IOException("Cannot claim USB interface")
        }
        conn = c
        intf = f
        c.controlTransfer(0x21, 0xFF, 0, f.id, null, 0, 5000) // Bulk-Only Mass Storage Reset
        waitReady()
        readCapacity()
    }

    private fun waitReady() {
        repeat(10) {
            try {
                scsi(ByteArray(6), 0, null) // TEST UNIT READY
                return
            } catch (ignored: IOException) {
                try {
                    scsi(byteArrayOf(3, 0, 0, 0, 18, 0), 18, ByteArray(18), true) // REQUEST SENSE
                } catch (ignored2: IOException) {
                }
                Thread.sleep(500)
            }
        }
        throw IOException("Drive not ready")
    }

    private fun readCapacity() {
        val cdb = ByteArray(10)
        cdb[0] = 0x25 // READ CAPACITY(10)
        val r = ByteArray(8)
        scsi(cdb, 8, r, true)
        val b = ByteBuffer.wrap(r)
        val last = b.getInt(0).toLong() and 0xFFFFFFFFL
        blockSize = b.getInt(4)
        if (last == 0xFFFFFFFFL) throw IOException("Drives over 2 TB are not supported")
        if (blockSize <= 0 || blockSize > 4096 || (1 shl 20) % blockSize != 0)
            throw IOException("Unsupported block size $blockSize")
        blockCount = last + 1
    }

    private fun write(lba: Long, buf: ByteArray, len: Int) {
        val cdb = ByteArray(10)
        cdb[0] = 0x2A // WRITE(10)
        val b = ByteBuffer.wrap(cdb)
        b.putInt(2, lba.toInt())
        b.putShort(7, (len / blockSize).toShort())
        scsi(cdb, len, buf)
    }

    /** Writes the stream raw from LBA 0 (like Rufus "DD Image" mode). */
    fun writeImage(input: InputStream, imageSize: Long, onProgress: (Long) -> Unit) {
        if (imageSize > sizeBytes)
            throw IOException("Image (${imageSize shr 20} MB) is larger than the drive (${sizeBytes shr 20} MB)")
        val buf = ByteArray(1 shl 20)
        var lba = 0L
        var done = 0L
        while (true) {
            var filled = 0
            while (filled < buf.size) {
                val n = input.read(buf, filled, buf.size - filled)
                if (n < 0) break
                filled += n
            }
            if (filled == 0) break
            val padded = (filled + blockSize - 1) / blockSize * blockSize
            if (padded > filled) java.util.Arrays.fill(buf, filled, padded, 0.toByte())
            write(lba, buf, padded)
            lba += padded / blockSize
            done += filled
            onProgress(done)
            if (filled < buf.size) break
        }
        try {
            val sync = ByteArray(10)
            sync[0] = 0x35 // SYNCHRONIZE CACHE(10)
            scsi(sync, 0, null)
        } catch (ignored: IOException) {
        }
    }

    private fun scsi(cdb: ByteArray, len: Int, buf: ByteArray?, dataIn: Boolean = false) {
        val t = tag++
        val cbw = ByteBuffer.allocate(31).order(ByteOrder.LITTLE_ENDIAN)
        cbw.putInt(0x43425355).putInt(t).putInt(len)
        cbw.put(if (dataIn) 0x80.toByte() else 0.toByte()).put(0.toByte()).put(cdb.size.toByte())
        cbw.put(cdb)
        bulk(epOut, cbw.array(), 31)
        if (len > 0 && buf != null) bulk(if (dataIn) epIn else epOut, buf, len)
        val csw = ByteArray(13)
        bulk(epIn, csw, 13)
        val r = ByteBuffer.wrap(csw).order(ByteOrder.LITTLE_ENDIAN)
        if (r.getInt(0) != 0x53425355 || r.getInt(4) != t) throw IOException("Bad USB response")
        if (csw[12].toInt() != 0) throw IOException("SCSI command 0x%02x failed".format(cdb[0]))
    }

    private fun bulk(ep: UsbEndpoint, buf: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val n = conn!!.bulkTransfer(ep, buf, off, minOf(16384, len - off), 30000)
            if (n <= 0) throw IOException("USB transfer failed")
            off += n
        }
    }

    override fun close() {
        try {
            intf?.let { conn?.releaseInterface(it) }
        } finally {
            conn?.close()
            conn = null
        }
    }
}
