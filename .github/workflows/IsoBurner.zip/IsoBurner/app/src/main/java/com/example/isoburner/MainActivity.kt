package com.example.isoburner

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private val permAction = "com.example.isoburner.USB_PERMISSION"
    private lateinit var usb: UsbManager
    private lateinit var spinner: Spinner
    private lateinit var isoText: TextView
    private lateinit var status: TextView
    private lateinit var bar: ProgressBar
    private lateinit var startBtn: Button
    private var drives = listOf<UsbDevice>()
    private var isoUri: Uri? = null
    private var isoSize = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == permAction) {
                val d = if (Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
                else i.getParcelableExtra<UsbDevice>(UsbManager.EXTRA_DEVICE)
                if (d != null && i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) confirm(d)
                else status.text = "USB permission denied"
            } else refresh()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        usb = getSystemService(Context.USB_SERVICE) as UsbManager
        fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

        spinner = Spinner(this)
        isoText = TextView(this).apply { text = "No ISO selected" }
        status = TextView(this).apply { setPadding(0, dp(12), 0, 0) }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        startBtn = Button(this).apply { text = "START"; setOnClickListener { start() } }
        val refreshBtn = Button(this).apply { text = "Refresh drives"; setOnClickListener { refresh() } }
        val isoBtn = Button(this).apply { text = "Select ISO file"; setOnClickListener { pickIso() } }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(20))
        }
        listOf(TextView(this).apply { text = "USB drive" }, spinner, refreshBtn, isoBtn, isoText, startBtn, bar, status)
            .forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })

        val f = IntentFilter(permAction).apply {
            addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        unregisterReceiver(receiver)
        super.onDestroy()
    }

    private fun refresh() {
        drives = usb.deviceList.values.filter { UsbMassStorage.findInterface(it) != null }
        val names = drives.map { d ->
            (runCatching { d.productName }.getOrNull() ?: "USB drive") +
                String.format(" (%04x:%04x)", d.vendorId, d.productId)
        }
        spinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            names.ifEmpty { listOf("No USB drive found") }
        )
    }

    private fun pickIso() {
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 1
        )
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data
        if (req != 1 || res != RESULT_OK || uri == null) return
        var name = "image"
        var size = 0L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        isoUri = uri
        isoSize = size
        isoText.text = "$name (${size shr 20} MB)"
    }

    private fun start() {
        val d = drives.getOrNull(spinner.selectedItemPosition)
        if (d == null) { status.text = "Plug in a USB drive and tap Refresh"; return }
        if (isoUri == null) { status.text = "Select an ISO first"; return }
        if (usb.hasPermission(d)) { confirm(d); return }
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        usb.requestPermission(
            d, PendingIntent.getBroadcast(this, 0, Intent(permAction).setPackage(packageName), flags)
        )
    }

    private fun confirm(d: UsbDevice) {
        val uri = isoUri ?: return
        // Hybrid ISOs (Linux etc.) carry an MBR with the 0x55AA signature; Windows ISOs don't.
        val hybrid = runCatching {
            contentResolver.openInputStream(uri)!!.use { s ->
                val h = ByteArray(512)
                var n = 0
                while (n < 512) {
                    val r = s.read(h, n, 512 - n)
                    if (r < 0) break
                    n += r
                }
                n == 512 && h[510] == 0x55.toByte() && h[511] == 0xAA.toByte()
            }
        }.getOrDefault(false)
        val warn = if (hybrid) "" else
            "\n\nWarning: this ISO has no hybrid boot sector (typical of Windows ISOs). " +
                "It probably won't boot after a raw write."
        AlertDialog.Builder(this)
            .setTitle("Erase USB drive?")
            .setMessage("ALL data on the selected drive will be destroyed.$warn")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Write") { _, _ -> burn(d, uri) }
            .show()
    }

    private fun burn(d: UsbDevice, uri: Uri) {
        val size = isoSize
        startBtn.isEnabled = false
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status.text = "Opening drive..."
        Thread {
            val msg = try {
                UsbMassStorage(usb, d).use { drive ->
                    drive.open()
                    var last = -1
                    contentResolver.openInputStream(uri)!!.use { input ->
                        drive.writeImage(input, size) { done ->
                            val pct = if (size > 0) (done * 100 / size).toInt().coerceAtMost(100) else 0
                            if (pct != last) {
                                last = pct
                                runOnUiThread { bar.progress = pct; status.text = "Writing... $pct%" }
                            }
                        }
                    }
                }
                "Done. Eject the drive and boot from it."
            } catch (e: Exception) {
                "Failed: ${e.message}"
            }
            runOnUiThread {
                status.text = msg
                startBtn.isEnabled = true
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        }.start()
    }
}
